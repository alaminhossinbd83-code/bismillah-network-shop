বিসমিল্লাহ নেটওয়ার্ক শপ — ক্লাউড অ্যাপ স্টার্টার
================================================

এই প্যাকেজে আছে:
- PWA ওয়েব অ্যাপের ফাইল
- Firebase Authentication দিয়ে অ্যাডমিন লগইন
- Firestore-এ পণ্য, অর্ডার ও দোকানের সেটিংস
- Firebase Storage-এ পণ্যের ছবি আপলোড
- owner (মূল অ্যাডমিন) এবং admin (দ্বিতীয় অ্যাডমিন) ভূমিকা
- bKash/Nagad Send Money নম্বর 01751994483 এবং TrxID নোট

গুরুত্বপূর্ণ সীমাবদ্ধতা:
এটি ক্লাউড-সংযুক্ত করার জন্য প্রস্তুত স্টার্টার প্যাকেজ; এখনো আপনার Firebase প্রজেক্টে যুক্ত বা অনলাইনে প্রকাশ করা হয়নি। তাই এখনই দুই ফোনে কাজ করবে না। Firebase প্রজেক্টের Config বসানো, নিরাপত্তা Rules প্রকাশ, প্রথম owner তৈরি এবং HTTPS Hosting করতে হবে। APK-ও এখনো তৈরি হয়নি।

ধাপ ১ — Firebase প্রজেক্ট
1. Chrome থেকে https://console.firebase.google.com খুলুন এবং Google অ্যাকাউন্ট দিয়ে সাইন ইন করুন।
2. Add project চাপুন; নাম দিন bismillah-network-shop (অথবা আপনার পছন্দের নাম)।
3. Project তৈরি হলে Project Overview > Web (</>) আইকনে চাপুন। App nickname দিন Bismillah Shop; Register app করুন।
4. Firebase যে firebaseConfig দেখাবে, সেটি এই প্যাকেজের firebase-config.js ফাইলে বসান। PASTE_API_KEY_HERE, YOUR_PROJECT_ID ইত্যাদি জায়গায় আসল মান বসাবেন।
5. Authentication > Get started > Sign-in method > Email/Password চালু করুন।
6. Firestore Database > Create database করুন (Production mode বেছে নিন)।
7. Storage > Get started করুন।

ধাপ ২ — প্রথম মূল অ্যাডমিন
1. Firebase Console > Authentication > Users > Add user থেকে নিজের ইমেইল ও একটি শক্তিশালী পাসওয়ার্ড দিয়ে প্রথম ব্যবহারকারী তৈরি করুন।
2. ওই ব্যবহারকারীর UID কপি করুন।
3. Firestore Database-এ users নামে collection তৈরি করুন। Document ID হিসেবে ওই UID দিন।
4. ওই document-এ role নামে string field দিন, value হবে owner।
5. নিজের পাসওয়ার্ড কাউকে দেবেন না।

ধাপ ৩ — দ্বিতীয় অ্যাডমিন
1. Authentication > Users > Add user থেকে দ্বিতীয় অ্যাডমিনের জন্য আলাদা ইমেইল/পাসওয়ার্ড তৈরি করুন।
2. তার UID কপি করুন।
3. Firestore users collection-এ UID-কে Document ID করে role: admin দিন।
4. দ্বিতীয় অ্যাডমিন নিজের লগইন ব্যবহার করবেন। তিনি পণ্য ও অর্ডার পরিচালনা করতে পারবেন; দোকানের পেমেন্ট/ডেলিভারি সেটিংস শুধু owner বদলাতে পারবেন।

ধাপ ৪ — নিরাপত্তা Rules
1. Firestore Database > Rules খুলে firestore.rules ফাইলের সম্পূর্ণ লেখা পেস্ট করে Publish করুন।
2. Storage > Rules খুলে storage.rules ফাইলের সম্পূর্ণ লেখা পেস্ট করে Publish করুন।
3. Rules প্রকাশ না করে অ্যাপ ব্যবহার করবেন না।

ধাপ ৫ — অনলাইনে প্রকাশ
1. Firebase Hosting চালু করতে কম্পিউটারে Node.js ও Firebase CLI লাগবে। কমান্ড:
   npm install -g firebase-tools
   firebase login
   firebase init hosting
2. Public directory হিসেবে এই ফোল্ডারটি ব্যবহার করুন; Single-page app প্রশ্নে No দিন।
3. firebase deploy চালান।
4. পাওয়া https://...web.app ঠিকানাটি Chrome-এ খুলুন। Chrome মেনু > Add to Home screen / Install app দিয়ে PWA ইনস্টল করা যাবে।

APK:
ওয়েবসাইট HTTPS-এ প্রকাশ ও পরীক্ষা হওয়ার পর PWABuilder দিয়ে Android APK/AAB তৈরি করা যাবে। এই ZIP-এ APK ফাইল নেই।

ফোন থেকে সহজে সেটআপে সাহায্য লাগলে Firebase Console-এর Project settings > General > Your apps-এর Firebase config অংশের স্ক্রিনশট পাঠাতে পারেন। API key সাধারণত Firebase web config-এ প্রকাশ্য client config; তবে কখনোই password, OTP, service-account private key বা Google account access দেবেন না।

পেমেন্ট:
bKash/Nagad Send Money নম্বর: 01751994483। গ্রাহক TrxID দেবেন; অ্যাডমিন নিজে লেনদেন মিলিয়ে payment status Verified করবেন। অ্যাপ স্বয়ংক্রিয়ভাবে টাকা যাচাই করে না।
